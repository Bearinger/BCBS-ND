package com.bearingers.encoder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Decoder {

	private ArrayList<String> linesToLearn;

	private BufferedReader learnInput;
	
	private Map<Character, Character> characterMap;
	
	private static PrintWriter log = null;

	public Decoder() {
	
		linesToLearn = new ArrayList<String>();
		characterMap = new HashMap<Character, Character>();

	}

	/**
	 * Read a file with encode/decode pairs.  Expects them to be
	 * alternating within file; encoded line then decoded line.
	 * @param learningFilePath
	 */
	private void readLearnFile(String learningFilePath){
		try {
			//open our input stream and read lines into ArrayList
			learnInput = new BufferedReader(new FileReader(new File(learningFilePath)));
			String line;
			if(learnInput.ready()){
				while((line = learnInput.readLine()) != null){
					linesToLearn.add(line);
				}
			}
			//close our input stream
			learnInput.close();
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method takes the encoded and decoded strings and digests
	 * them into characters and attempts to learn the algorithm used.
	 * @param encoded
	 * @param decoded
	 */
	private void digest(String encoded, String decoded){
		//assume strict character replacement - no padding
		if(encoded.length() != decoded.length())
			return;
		
		//already determined same length
		int len = encoded.length();
		char enc, dec;
		
		for(int index = 0;index < len;index++){
			//get the character at location in each string
			enc = encoded.charAt(index);
			dec = decoded.charAt(index);
			
			//use a HashMap to map encoded and decoded values
			if(!characterMap.containsKey(enc)){
				characterMap.put(enc, dec);
			}
			else{
				//collision; see if they are the same - if so ignore - else log collision
				char check = characterMap.get(enc);
				if(check != dec)
					Decoder.toLog("Collision: " + enc + " -> " + dec + ", with existing: " + check);
			}
		
		}

	}

	/**
	 * Decodes a string using the last replacement algorithm learned.
	 * @param encoded
	 * @return A String representing the decoded value.  Returns null in the event
	 * an algorithm has not been learned or only partially learned.
	 * @see public void learn(String learningFilePath)
	 */
	public String decode(String encoded){
		StringBuilder decoded = new StringBuilder();
		
		int len = encoded.length();
		
		for(int index = 0;index < len;index++){
			Character dec = characterMap.get(encoded.charAt(index));
			//if we find a decoded value add to string builder
			if(dec != null)
				decoded.append(dec);
			else
				//else return null - learning algorithm is incomplete
				return null;
		}


		return decoded.toString();
	}

	/**
	 * Learn encode/decode algorithm based on encode/decode pairs
	 * contained in file.  Expects the input lines to be
	 * alternating within file; encoded line then decoded line.
	 * @param learningFilePath
	 */
	public void learn(String learningFilePath){
		//get the data from the input file
		this.readLearnFile(learningFilePath);
		
		String encoded= null;
		String decoded = null;
		
		//assume failure
		boolean readyToDigest = false;
		
		Iterator<String> it = linesToLearn.iterator();
		
		//iterate over the input pairing encoded/decoded lines
		while(it.hasNext()){
			encoded = it.next();
			if(it.hasNext()){
				decoded = it.next();
				readyToDigest = true;
			}

			//if a matching encoded/decoded pair are found digest for learning
			if(readyToDigest){
				digest(encoded, decoded);
			}
			//assume failure next time through
			readyToDigest = false;
			
		}
		
	}

	/**
	 * Simple static logging method to write String data to the Log File.
	 * @param str
	 */
	public static void toLog(String str){
		try {
			if(log == null)
				log = new PrintWriter(new File("log.txt"));
			
			log.println(str);
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		finally{
			log.flush();
		}

	}
	
	public static void main(String[] args) {
		Decoder decoder = new Decoder();
		try {
			//grab the input file and create the output
			BufferedReader input = new BufferedReader(new FileReader("input.txt"));
			PrintWriter output = new PrintWriter(new File("output.txt"));
			
			//send the learning file to the decoder
			decoder.learn("learnFile.txt");
			
			String decoded = null;
			
			String line;
			if(input.ready()){
				while((line = input.readLine()) != null){
					decoded = decoder.decode(line);
					if(decoded != null)
						output.println(decoded);
					else
						Decoder.toLog("Failed to decode: " + line);
				}
			}
			//close our input stream
			input.close();
			output.close();
			
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}

	}

}
