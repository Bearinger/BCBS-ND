package com.bearingers.pto;

public class Employee {

	private String firstName;
	private String lastName;
	private long empID;
	
	public Employee(String firstName, String lastName, long empID) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.empID = empID;
	}

	@Override
	public boolean equals(Object o){
		//if not an employee o can't be equal
		if(o == null || !(o instanceof Employee))
			return false;
		
		Employee emp = (Employee)o;
		
		return ((this.empID == emp.empID) && (this.firstName.equals(emp.firstName)) && (this.lastName.equals(emp.lastName)));
	}

	@Override
	public int hashCode(){
		return ((Long)empID).hashCode();
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public long getEmpID() {
		return empID;
	}

	public void changeFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void changeLastName(String lastName) {
		this.lastName = lastName;
	}

}
