package com.bearingers.pto;

public class LeaveRequest {

	private Employee emp;
	private int hoursRequested;
	
	
	public LeaveRequest(Employee emp, int hours) {
		this.emp = emp;
		hoursRequested = hours;
	}


	public Employee getEmployee() {
		return emp;
	}


	public int getHoursRequested() {
		return hoursRequested;
	}

}
