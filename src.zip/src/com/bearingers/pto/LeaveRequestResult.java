package com.bearingers.pto;

public class LeaveRequestResult {

	public LeaveRequestResult() {
		//stubbed
	}

}
