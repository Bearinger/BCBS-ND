package com.bearingers.pto;

public interface LeaveResultListener {

	/**
	 * Listener method to receive the results of a Leave Request.
	 */
	public void processResult(LeaveRequestResult result);

}
