package com.bearingers.pto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

public class PtoManager extends Thread{

	/**Map to track available PTO for employees - in lieu of a database*/
	private Map<Employee, Integer> leaveBalances;

	private ConcurrentLinkedQueue<LeaveRequest> requestQ;
	
	private List<LeaveResultListener> listeners;

	private boolean keepProcessing;

	public PtoManager() {
		requestQ = new ConcurrentLinkedQueue<LeaveRequest>();
		listeners = new ArrayList<LeaveResultListener>();

		//init things that need more than a constructor call
		init();
	}

	private void init(){
		//this is where you would read in any persisted data from file
		//or establish DB connections if persisted in a database
		leaveBalances = new HashMap<Employee, Integer>();
	}

	@Override
	public void start(){
		//make sure our thread keeps running after startup
		keepProcessing = true;
		super.start();
	}

	@Override
	public void run() {
		
		while(keepProcessing){
			//grab request if there is one
			LeaveRequest req = requestQ.peek();
			
			if(req != null){
				//handle request
				handleRequest(req.getEmployee(), req.getHoursRequested());
				
				//remove request now that it is processed
				requestQ.poll();
			}
			else{
				//no request so wait until there is a notify
				synchronized (requestQ) {
					try {
						requestQ.wait();
					} catch (InterruptedException e) {/*ignore*/}
				}
			}
		}
		
	}

	/**
	 * Internal method to handle a request.
	 * @param req
	 */
	private void handleRequest(Employee emp, int hours){
		//check if the leave requested by employee is available
		//checking map - could use a database connection and query instead
		if(leaveBalances.containsKey(emp)){
			int available = leaveBalances.get(emp);
			if(available > hours)
				leaveBalances.put(emp, available-hours);
		}
		
		//create a result and fill in all necessary info... currently just stubbed
		LeaveRequestResult result = new LeaveRequestResult();
		
		synchronized (listeners) {
			//notify anyone listening for the results of the request
			Iterator<LeaveResultListener> it = listeners.iterator();
			while(it.hasNext())
				it.next().processResult(result);
		}
		
	}

	/**
	 * Add an employee and a starting balance which can be zero.
	 * @param emp
	 * @param startingPtoBalance
	 */
	public void addEmployee(Employee emp, int startingPtoBalance){
		//ensure not overwriting an existing entry
		if(!leaveBalances.containsKey(emp)){
			if(startingPtoBalance >= 0)
				leaveBalances.put(emp, startingPtoBalance);
			else
				leaveBalances.put(emp, 0);
		}	
	}

	/**
	 * Update an existing employee's hours.  The value in hourAdjustment
	 * will be added to the current balance.  This value can be positive
	 * or negative to compensate adding or subtracting hours from the
	 * remaining balance.
	 * @param emp
	 * @param startingPtoBalance
	 */
	public void updateEmployee(Employee emp, int hourAdjustment){
		//ensure the employee exists
		if(leaveBalances.containsKey(emp)){
			int newHours = leaveBalances.get(emp) + hourAdjustment;
			if(newHours >= 0)
				leaveBalances.put(emp, newHours);
			else
				leaveBalances.put(emp, 0);
		}	
	}

	public void addResultListener(LeaveResultListener listener){
		//ensure we don't add twice
		synchronized (listeners) {
			if(!listeners.contains(listener))
				listeners.add(listener);
		}
		
	}

	/**
	 * Method to add a request to the queue for processing.
	 * @param req
	 */
	public void processRequest(LeaveRequest req){
		synchronized(requestQ){
			try{
				if(requestQ.offer(req))
					requestQ.notify();
			}
			catch(IllegalMonitorStateException ime){
				//ignore or log - request won't get processed
			}
		}
	}

	/**
	 * Stop this thread.  This method will allow the run()
	 * method to exit gracefully.
	 */
	public void stopThread(){
		synchronized(requestQ){
			try{
				keepProcessing = false;
				requestQ.notify();
			}
			catch(IllegalMonitorStateException ime){/*ignore*/}
		}
		
	}

	public static void main(String[] args) {
		//create and launch thread that will process all leave requests
		Thread ptoMgr = new PtoManager();
		ptoMgr.start();
	}
}
